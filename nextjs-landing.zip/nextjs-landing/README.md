# Nextjs Landing

Мінімальний landing page на Next.js 16 (App Router, JavaScript, без TypeScript, без Tailwind). Темна тема реалізована на чистому CSS (`app/globals.css`).

## Запуск

```bash
npm install
npm run dev
```

Відкрий http://localhost:3000

## Структура

```
app/
  layout.js     — кореневий layout, підключення globals.css
  page.js       — головна сторінка (hero, features, footer)
  globals.css   — стилі темної теми
next.config.js  — конфіг Next.js
package.json    — залежності (next, react, react-dom)
```

## Примітка

`package-lock.json` навмисно відсутній і доданий у `.gitignore` — він згенерується автоматично після `npm install`.
