export default function HomePage() {
  return (
    <>
      <header className="header">
        <div className="container header__inner">
          <div className="logo">Acme</div>
          <nav className="nav">
            <a href="#features">Можливості</a>
            <a href="#pricing">Ціни</a>
            <a href="#contact">Контакти</a>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="container">
            <span className="hero__badge">Нове • Версія 1.0</span>
            <h1>Створюй швидше з мінімальним лендінгом на Next.js</h1>
            <p>
              Готовий шаблон з темною темою, App Router та без зайвих
              залежностей. Просто підключи свій контент і запускай.
            </p>
            <div className="hero__actions">
              <a href="#" className="btn btn--primary">
                Почати безкоштовно
              </a>
              <a href="#features" className="btn btn--secondary">
                Дізнатися більше
              </a>
            </div>
          </div>
        </section>

        <section className="features" id="features">
          <div className="container features__grid">
            <div className="card">
              <div className="card__icon">⚡</div>
              <h3>Швидкий старт</h3>
              <p>Мінімум залежностей і чиста структура App Router.</p>
            </div>
            <div className="card">
              <div className="card__icon">🌙</div>
              <h3>Темна тема</h3>
              <p>Стильний темний дизайн без Tailwind, на чистому CSS.</p>
            </div>
            <div className="card">
              <div className="card__icon">🧩</div>
              <h3>Просто розширити</h3>
              <p>Прості компоненти, які легко адаптувати під свій проєкт.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer" id="contact">
        <div className="container footer__inner">
          <span>© {new Date().getFullYear()} Acme. Усі права захищені.</span>
          <span>hello@acme.dev</span>
        </div>
      </footer>
    </>
  );
}
